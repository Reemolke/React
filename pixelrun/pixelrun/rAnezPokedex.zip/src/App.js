import './App.css';
import Screen from './components/screen.js';
function App() {
  return (
    
    <div class="index">
      <Screen/>
    </div>
  );
}

export default App;
